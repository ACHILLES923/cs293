#include "dictionary.h"
#include <cmath>
#include <climits>
using namespace std;

//Constructor 
Dictionary::Dictionary(){
	N = DICT_SIZE;
	A = new Entry[N];
	
	for(int i=0; i<N; i++)
	{
		struct Entry* e = new Entry();  
		A[i] = *e;
	}
}		


int Dictionary::hashValue(char key[]){
	//First convert key(string) to key(int) using ASCII values of characters and horners rule.	
	
	//Implementation of hash code map using x=33
	int keyInt, keySize = 0, x = 33;
	
	while(key[keySize] != '\0'){
		keySize++;
	}
	
	keyInt = key[keySize-1];
	
	for(int i=keySize-2; i>=0; i--)
	{
		keyInt = keyInt*x +key[i];
	}
	
		
	//Implementation of hash compression map
	
	double A = (sqrt(5) - 1)/2;
	
	// This is fibonacci hashing
	
	int hashKey = keyInt*A;
	hashKey = floor(DICT_SIZE*(hashKey - int(hashKey)));
	
	
	return hashKey;
}

int Dictionary::findFreeIndex(char key[]){
	
	//Compute slot value where data can be entered
	int slot = hashValue(key), tries = 0;
	
	//until we find a slot which is null and number of tries is less than DICT_SIZE, we keep probing. Since hash table is of size DICT_SIZE, if tries is greater than DICT_SIZE, then it means that we have circularly moved around in the array, so that means no empty slot. 
	while(tries<DICT_SIZE)
	{	
		if(A[slot].getValue() == INT_MIN || A[slot].checkForTombStone()) break;
		
		slot = (slot+1)%DICT_SIZE;
		tries++;
	}
	
	if(tries<DICT_SIZE) return slot;
	else return -1;
}


bool Dictionary::put(struct Entry e){

	//Calculating free slot in hash table
	int slot;
	char* key = e.getKey();
	slot = findFreeIndex(key);
	
	if(slot == -1) return false;
	
	A[slot] = e;
	return true;
}


struct Entry* Dictionary::get(char key[]){
	

	int hashedValue = hashValue(key);
	
	while(A[hashedValue].getValue() != INT_MIN)
	{
		//if it is a tombstone, then skip it
		if(A[hashedValue].checkForTombStone())
		{
			hashedValue = (hashedValue+1)%DICT_SIZE;
			continue;
		}	
		
		bool areTwoKeySame;
		
		char* key1 = A[hashedValue].getKey(), *key2 = key;	
		// Checks if two keys are same.	
		
		int key1Size=0, key2Size = 0;
	
		//Calculating key1 size
		while(key1[key1Size]!='\0'){
			key1Size++;
			}
	
		//calculating key2 size
		while(key2[key2Size]!='\0'){
			key2Size++;
		}
	
		// If different size, then can't be same keys
		if(key1Size != key2Size) areTwoKeySame = false;
		
		//Same size
		for(int i=0; i<key1Size; i++)
		{
			//If any key different, then false
			if(key1[i] != key2[i]) areTwoKeySame = false;
		}
	
		areTwoKeySame = true;
		
		if(areTwoKeySame) return &A[hashedValue];
		
		hashedValue = (hashedValue+1)%DICT_SIZE;
	}
	
	return NULL;
	
	
}


bool Dictionary::remove(char key[]){

	int hashedValue = hashValue(key);
	
	while(A[hashedValue].getValue() !=INT_MIN)
	{	
		if(A[hashedValue].checkForTombStone())
		{
			hashedValue = (hashedValue+1)%DICT_SIZE;
			continue;
		}	
		
		bool areTwoKeySame;	
		
		char* key1 = A[hashedValue].getKey(), *key2 = key;
		// Checks if two keys are same.	
		
		int key1Size=0, key2Size = 0;
	
		//Calculating key1 size
		while(key1[key1Size]!='\0'){
			key1Size++;
			}
	
		//calculating key2 size
		while(key2[key2Size]!='\0'){
			key2Size++;
		}
	
		// If different size, then can't be same keys
		if(key1Size != key2Size) areTwoKeySame = false;
		
		//Same size
		for(int i=0; i<key1Size; i++)
		{
			//If any key different, then false
			if(key1[i] != key2[i]) areTwoKeySame = false;
		}
	
		areTwoKeySame = true;		
		
		
		//If key found, then return entry
		if(areTwoKeySame)
		{
			A[hashedValue].makeTombStone();
			return true;
		}	
		
		hashedValue = (hashedValue+1)%DICT_SIZE;
	}
	
	return false;
}			 
