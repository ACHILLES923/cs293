#ifndef PLANNER_H
#define PLANNER_H

#include "dictionary.cpp"


class Planner {
  	// define suitable fields here
  protected:
  	Dictionary D;
  	
  public:

  	void run();
};

#endif
